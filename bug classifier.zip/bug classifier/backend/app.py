import os
import json
import re
import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Bug Classifier & Corrector API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- FIX 1: Make sure to replace this with your REAL API key ---
# You get this from Google AI Studio (https://aistudio.google.com/app/apikey)
GEMINI_API_KEY = "AIzaSyAMmfcrFgT1AiVh8CJh7-Y-33_Ns3XdxmI" 
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

# --- FIX 2: The API key must be in the URL, not in a Bearer header ---
GEMINI_ENDPOINT = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"

if not GEMINI_API_KEY or "YOUR_REAL_API_KEY" in GEMINI_API_KEY:
    print("="*50)
    print("WARNING: GEMINI_API_KEY is not set or is still the placeholder!")
    print("Please set your real API key in app.py.")
    print("="*50)

class AnalyzeRequest(BaseModel):
    language: str
    code: str

@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    prompt = (
        f"You are an expert code reviewer. Language: {req.language}\n\n"
        "Analyze the following code for bugs, syntax errors, logic issues, and security problems. "
        "Return a JSON object EXACTLY with keys: 'summary' (short text), 'issues' (list of strings), "
        "'corrected_code' (the corrected code as a single string). "
        "If there are no issues set 'issues' to an empty list and 'corrected_code' to the original code.\n\n"
        "CODE:\n" + req.code
    )

    # --- FIX 3: The payload structure for the Gemini API is different ---
    # It requires a 'contents' object, not a 'prompt' string.
    payload = {
        "contents": [
            {"role": "user", "parts": [{"text": prompt}]}
        ],
        "generationConfig": {
            "maxOutputTokens": 2048, # <-- INCREASED VALUE
            "temperature": 0.0
        }
    }

    # --- FIX 4: Remove the 'Authorization' header. The key is in the URL. ---
    headers = {
        "Content-Type": "application/json",
    }

    try:
        # The URL (GEMINI_ENDPOINT) now contains the API key
        resp = requests.post(GEMINI_ENDPOINT, headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise HTTPException(status_code=504, detail=str(e))

    raw = resp.text
    if not resp.ok:
        raise HTTPException(status_code=502, detail=f"Gemini API error: {resp.status_code} - {raw[:500]}")

    candidate_text = None
    try:
        obj = resp.json()
    except Exception:
        obj = None

    # This extraction logic seems fine, but Gemini responses
    # usually follow this structure:
    if isinstance(obj, dict):
        try:
            # Standard path for generateContent
            candidate_text = obj["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError, TypeError):
            # Corrected Fallback:
            try:
                if "candidates" in obj and obj["candidates"]:
                    c = obj["candidates"][0]
                    if c.get("content"): # 'content' is a dict
                        candidate_text = c["content"]["parts"][0]["text"]
                    elif c.get("output"): # 'output' is often a string
                        candidate_text = c.get("output")
                    elif c.get("text"): # 'text' is often a string
                        candidate_text = c.get("text")
                elif "output" in obj: # Checking other common structures
                        out = obj["output"]
                        if isinstance(out, dict):
                            candidate_text = out.get("content") or out.get("text")
                        elif isinstance(out, str):
                            candidate_text = out
                elif "choices" in obj and obj["choices"]: # OpenAI style
                    ch = obj["choices"][0]
                    if isinstance(ch.get("message"), dict):
                        candidate_text = ch["message"].get("content") or ch.get("text")
                    else:
                        candidate_text = ch.get("text")
            except (KeyError, IndexError, TypeError, AttributeError):
                # If all parsing fails, stringify the object for debugging
                try:
                    candidate_text = json.dumps(obj)
                except Exception:
                    candidate_text = raw # Final fallback
                        
    if not candidate_text:
        candidate_text = raw
        
    # Try to parse JSON from the candidate_text
    parsed = None
    try:
        # The model might return ```json ... ```, so strip that.
        clean_text = candidate_text.strip().replace("```json", "").replace("```", "")
        parsed = json.loads(clean_text)
    except Exception:
        m = re.search(r"(\{[\s\S]*?\"summary\"[\s\S]*?\})", candidate_text)
        if m:
            try:
                parsed = json.loads(m.group(1))
            except Exception:
                parsed = None

    if not parsed:
        return {
            "summary": "Could not parse Gemini response as structured JSON.",
            "issues": [candidate_text[:1500]],
            "corrected_code": req.code,
        }

    summary = parsed.get("summary", "")
    issues = parsed.get("issues", [])
    corrected = parsed.get("corrected_code") or parsed.get("correctedCode") or ""

    if corrected == "":
        corrected = req.code

    return {"summary": summary, "issues": issues, "corrected_code": corrected}  