// script.js

document.addEventListener("DOMContentLoaded", () => {
  const analyzeBtn = document.getElementById("analyzeBtn");
  
  // --- FIX 1: Correct all element IDs to match index.html ---
  const codeInput = document.getElementById("code"); // Was "codeInput"
  const languageSelect = document.getElementById("language"); // Was "languageSelect"
  const outputSection = document.getElementById("results"); // Was "outputSection"
  const summaryOutput = document.getElementById("issueSummary"); // Was "summaryOutput"
  // const issuesOutput = document.getElementById("issuesOutput"); // This element doesn't exist in HTML, remove it.
  const correctedCodeOutput = document.getElementById("correctedCode"); // Was "correctedCodeOutput"
  
  const downloadBtn = document.getElementById("downloadBtn");

  analyzeBtn.addEventListener("click", async () => {
    const code = codeInput.value.trim();
    const language = languageSelect.value;

    if (!code) {
      alert("Please enter some code to analyze!");
      return;
    }
    // --- FIX 2: Ensure language is selected ---
    if (!language) {
      alert("Please select a programming language!");
      return;
    }

    analyzeBtn.disabled = true;
    analyzeBtn.textContent = "Analyzing...";
    downloadBtn.disabled = true; // Disable download btn during analysis
    outputSection.style.display = "none";
    summaryOutput.innerHTML = ""; // Clear old results
    correctedCodeOutput.textContent = ""; // Clear old results

    try {
      const response = await fetch("http://localhost:8000/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, language }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(`Server returned ${response.status}: ${errData.detail || 'Unknown error'}`);
      }

      const data = await response.json();

      // --- FIX 3: Populate results correctly ---
      // We don't have a separate 'issuesOutput', so let's build a nice
      // summary in the 'summaryOutput' (which is 'issueSummary' in HTML)
      
      const summaryEl = document.createElement("p");
      summaryEl.textContent = data.summary || "No summary generated.";
      summaryOutput.appendChild(summaryEl);

      if (data.issues && data.issues.length > 0) {
          const issuesTitle = document.createElement("strong");
          issuesTitle.textContent = "Detected Issues:";
          summaryOutput.appendChild(issuesTitle);

          const issuesList = document.createElement("ul");
          data.issues.forEach(issue => {
              const li = document.createElement("li");
              li.textContent = issue;
              issuesList.appendChild(li);
          });
          summaryOutput.appendChild(issuesList);
      } else {
          const noIssuesEl = document.createElement("p");
          noIssuesEl.textContent = "No issues detected.";
          summaryOutput.appendChild(noIssuesEl);
      }

      correctedCodeOutput.textContent = data.corrected_code || "No corrected code available.";
      
      // --- FIX 4: Enable the download button ---
      if (data.corrected_code) {
        downloadBtn.disabled = false;
      }
      
      outputSection.style.display = "block";

    } catch (error) {
      console.error("Error:", error);
      // Show the error in the summary box
      summaryOutput.innerHTML = `<p><strong>Error:</strong> ${error.message}</p>`;
      outputSection.style.display = "block";
    } finally {
      analyzeBtn.disabled = false;
      analyzeBtn.textContent = "Analyze & Fix Bugs";
    }
  });

  // Download corrected code as a .txt file
  downloadBtn.addEventListener("click", () => {
    const code = correctedCodeOutput.textContent;
    if (!code || code === "No corrected code available.") {
      alert("No corrected code to download!");
      return;
    }

    const blob = new Blob([code], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    
    // Suggest a filename based on language
    const lang = languageSelect.value.toLowerCase() || 'txt';
    const extMap = { 'python': 'py', 'c': 'c', 'c++': 'cpp', 'java': 'java', 'php': 'php', 'html': 'html', 'r': 'r', 'javascript': 'js' };
    const extension = extMap[lang] || 'txt';
    
    link.download = `corrected_code.${extension}`;
    link.click();
    URL.revokeObjectURL(link.href); // Clean up
  });
});